# Nossa História — Android (protótipo inicial)

Este é o primeiro esqueleto visual do app em Kotlin + Jetpack Compose.

## O que já existe
- Identidade visual romântica em rosa e creme
- Navegação: Início, Memórias, Cartinhas e Conta
- Cartões de funcionalidades
- Formulário visual para uma nova lembrança (ainda não salva dados)

## O que ainda NÃO está conectado
Este protótipo ainda não tem cadastro/login, banco de dados, upload de fotos, gravação de áudio ou chamadas. Não coloque fotos ou informações privadas nele esperando que fiquem guardadas: o formulário atual é apenas visual.

## Abrir no Android Studio
1. Instale o Android Studio.
2. Escolha **Open** e selecione a pasta `NossaHistoriaAndroid`.
3. Aguarde o Gradle sincronizar.
4. Execute em um emulador ou celular Android com depuração USB ativada.

## Próxima etapa
Conectar Firebase Authentication, Cloud Firestore e Cloud Storage. Cada pessoa terá sua conta; um convite/código permitirá entrar no mesmo espaço compartilhado. As regras de segurança devem limitar o acesso aos dois membros autorizados. Depois serão adicionados upload de imagens, mensagens persistentes e áudios.

## Identificador inicial
`com.nossahistoria.app`

## Gerar APK pelo GitHub Actions (sem computador)
O projeto inclui o workflow `.github/workflows/android.yml`. Depois de enviar os arquivos para um repositório GitHub:
1. Abra a aba **Actions** do repositório.
2. Se necessário, habilite workflows.
3. Escolha **Gerar APK do Nossa História** e toque em **Run workflow**.
4. Quando terminar, abra a execução e baixe o artefato **Nossa-Historia-APK**.
5. Extraia o ZIP do artefato e instale `app-debug.apk` no Android.

Este APK é de depuração para testes, não uma versão pronta para publicação na Play Store.
